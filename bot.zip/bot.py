import json
import requests
import datetime

TELE_TOKEN='6523477120:AAGXPr7GcDwAqulqNNZ2nnolBRkh9hIhCK4'
URL = "https://api.telegram.org/bot{}/".format(TELE_TOKEN)

# a dictionary that stores all tasks
todos = {}

def start(chat_id):
  start_message = f"Hello! I'm a bot that will help you not to forget anything.😉" 
  send_message(start_message, chat_id)

def delete_task(chat_id, c_date, task):
  if todos.get(chat_id) is not None:
      if todos[chat_id].get(c_date) is not None:
          todos[chat_id][c_date].remove(task)
          if len(todos[chat_id][c_date]) == 0:
              del todos[chat_id][c_date]
          if len(todos[chat_id]) == 0:
              del todos[chat_id]

def add_task(chat_id, c_date, task):
  add_todo(chat_id, c_date, task)
  text = f'Task successfully added on {c_date} ✅'
  send_message(text, chat_id)

def add_todo(chat_id, c_date, task):
  if todos.get(chat_id) is not None:
      if todos[chat_id].get(c_date) is not None:
          todos[chat_id][c_date].append(task)
      else:
          todos[chat_id][c_date] = [task]
  else:
      todos[chat_id] = {c_date: [task]}

def send_message(text, chat_id):
  url = URL + "sendMessage?text={}&chat_id={}".format(text, chat_id)
  requests.post(url)

def lambda_handler(event, context):
  try:
      # Extract the relevant information from the event
      update = json.loads(event['body'])
      
      # Handle the Telegram bot logic based on the update
      command = update['message']['text']
      chat_id = update['message']['chat']['id']
      
      if command == '/start':
          start(chat_id)
      elif command == 'Add task 📝':
          # Handle the 'Add task' command
          pass
      elif command == 'Show tasks 📋':
          # Handle the 'Show tasks' command
          pass
      elif command == 'Help 🆘':
          # Handle the 'Help' command
          pass
      else:
          send_message("I don't understand... Press 'Help' in the menu 🙄", chat_id)
      
      # Return a response to the client (if using API Gateway)
      response = {
          "statusCode": 200,
          "body": "OK"
      }
  except Exception as e:
      print(f"Error processing update: {e}")
      response = {
          "statusCode": 500,
          "body": "Internal Server Error"
      }
  
  return response
